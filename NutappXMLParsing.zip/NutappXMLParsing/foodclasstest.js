//'title','calories', 'carbs', 'protein', 'fat', 'sugars', 'sodium', 'dietaryfiber'

module.exports = class Food {
    // Constructor method to initialize an object

    constructor(nutarray){
        this.title = nutarray[0];
        this.calories = nutarray[1];
        this.carbs = nutarray[2];
        this.protein = nutarray[3];
        this.fat = nutarray[4];
        this.sugars = nutarray[5];
        this.sodium = nutarray[6];
        this.dietaryfiber = nutarray[7];

        this.nutinfo =nutarray;
    }
    // Getter
    get data() {
        return this.nutinfo;
    }

    // getter
    get getName() {
        return this.title;
    }


    static combine(food1, food2){
        const combarray = [];
        combarray[0] = `${food1.title} & ${food2.title}`;
        combarray[1] = Number(food1.data[1]) + Number(food2.data[1]);
        combarray[2] = Number(food1.data[2]) + Number(food2.data[2]);
        combarray[3] = Number(food1.data[3]) + Number(food2.data[3]);
        combarray[4] = Number(food1.data[4]) + Number(food2.data[4]);
        combarray[5] = Number(food1.data[5]) + Number(food2.data[5]);
        combarray[6] = Number(food1.data[6]) + Number(food2.data[6]);
        combarray[7] = Number(food1.data[7]) + Number(food2.data[7]);

        return new Food(combarray);
    }

    static multcombine(array){
        let comb = array[0];
        for (let i = 1; i < array.length; i++) {
            comb = Food.combine(comb, array[i]);
        }
        return comb;
    }

    static turntoFood(item){
        const array = [];
        array[0] = item.title;
        array[1] = item.calories;
        array[2] = item.carbs;
        array[3] = item.protein;
        array[4] = item.fat;
        array[5] = item.sugars;
        array[6] = item.sodium;
        array[7] = item.dietaryfiber;
        return new Food(array);

    }
}