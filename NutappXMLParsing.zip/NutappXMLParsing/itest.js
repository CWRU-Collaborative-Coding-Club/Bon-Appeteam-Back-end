

const fs = require('fs');
const xml2js = require('xml2js');
var menuArray = [];

// Read the XML file
fs.readFile('./menu.xml', (err, data) => {
    if (err) {
        console.error(err);
        return;
    }

    // Parse the XML data
    xml2js.parseString(data, (err, result) => {
        if (err) {
            console.error(err);
            return;
        }

        // Output the parsed XML
        //console.log(JSON.stringify(result, null, 2));

        //const menuArray = [];
        const includedArray = ['title','calories', 'carbs', 'protein', 'fat', 'sugars', 'sodium', 'dietaryfiber'];



        // Extract and populate the array
        if (result && result.menu && result.menu.food) {
            result.menu.food.forEach(food => {
                const foodArray = [];
                // Iterate over the keys in each food object
                Object.keys(food).forEach(key => {
                    // Skip the id attribute

                    if (includedArray.includes(key)){
                        foodArray.push(food[key][0]);
                    }

                    //foodArray.push(food[key][0]);
                });
                // Add the foodArray to the menuArray
                menuArray.push(new Food(foodArray));
            });
        }


        console.log("\n \nScore Results:\n");
        for (let i = 0; i < menuArray.length; i++) {
            console.log((menuArray[i].getName) + ", diff: ");
            console.log(scoreMeal(menuArray[i].data));

        }

        const foodt = Food.combine(menuArray[0],menuArray[1]);
        console.log(menuArray[0].data);
        console.log(scoreMeal(menuArray[0].data));
        console.log(menuArray[1].data);
        console.log(scoreMeal(menuArray[1].data));

        console.log(foodt.data);
        console.log(scoreMeal(foodt.data));

        const foot = Food.multcombine(menuArray);
        console.log(foot.data);
        console.log(scoreMeal(foot.data));

    });
});





//for calculating nutrition deviation for a given food[]
function scoreMeal(arr) {
    const cal = Number(arr[1])
    const car = Number(arr[2])
    const pro = Number(arr[3])
    const fat = Number(arr[4])

    const sugar = Number(arr[5] ) //50g advised for 2000 cal : .025g per cal
    const sodium = Number(arr[6]) //1500mg advised for 2000 cal : .75mg per cal
    const fiber = Number(arr[7] ) //28g advised for 2000 cal : .014g per cal

    //hardcoded values for recommended macros, can be changed
    const cdiff = Math.abs(.45 - (car*4)/cal)
    const pdiff = Math.abs(.35 - (pro*4)/cal)
    const fdiff = Math.abs(.2 - (fat*9)/cal)
    //hardcoded values for recommended sugar, sodium, fiber
    const sudiff = Math.abs(.025 - sugar/cal)
    const sodiff = Math.abs(.75 - sodium/cal)
    const fibdiff = Math.abs(.014 - fiber/cal)

    return (cdiff + pdiff + fdiff + sudiff + sodiff + fibdiff)/6;

}

class Food {
    // Constructor method to initialize an object

    constructor(nutarray){
        this.title = nutarray[0];
        this.calories = nutarray[1];
        this.carbs = nutarray[2];
        this.protein = nutarray[3];
        this.fat = nutarray[4];
        this.sugars = nutarray[5];
        this.sodium = nutarray[6];
        this.dietaryfiber = nutarray[7];

        this.nutinfo =nutarray;
    }
    // Getter
    get data() {
        return this.nutinfo;
    }

    // getter
    get getName() {
        return this.title;
    }


    static combine(food1, food2){
        const combarray = [];
        combarray[0] = `${food1.title} & ${food2.title}`;
        combarray[1] = Number(food1.data[1]) + Number(food2.data[1]);
        combarray[2] = Number(food1.data[2]) + Number(food2.data[2]);
        combarray[3] = Number(food1.data[3]) + Number(food2.data[3]);
        combarray[4] = Number(food1.data[4]) + Number(food2.data[4]);
        combarray[5] = Number(food1.data[5]) + Number(food2.data[5]);
        combarray[6] = Number(food1.data[6]) + Number(food2.data[6]);
        combarray[7] = Number(food1.data[7]) + Number(food2.data[7]);

        return new Food(combarray);
    }

    static multcombine(array){
        let comb = array[0];
        for (let i = 1; i < array.length; i++) {
            comb = Food.combine(comb, array[i]);
        }
        return comb;
    }


}

