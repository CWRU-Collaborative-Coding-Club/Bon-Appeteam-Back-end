const readline = require('readline');
//Creating a user input interface
const rl = readline.createInterface({
    input: process.stdin,
    output:process.stdout
});

const {checkIfExists} = require("./leveldb/level");
const scoreMeal = require('./scoreMeal');

function foodCombo(combo) {
    let totalCalories = 0;
    let totalCarbs = 0;
    let totalProtein = 0;
    let totalFat = 0;
    let totalSugar = 0;
    let totalSodium = 0;
    let totalFiber = 0;
    let title = [];

    //food = ['title','calories', 'carbs', 'protein', 'fat', 'sugars', 'sodium', 'dietaryfiber'];
    for (let food of combo) {
        // TBD
        title.push(food[0]);

        totalCalories += parseFloat(food[1]);
        totalCarbs += parseFloat(food[2]);
        totalProtein += parseFloat(food[3]);
        totalFat += parseFloat(food[4]);
        totalSugar += parseFloat(food[5]);
        totalSodium += parseFloat(food[6]);
        totalFiber += parseFloat(food[7]);
    }


    let totals = [
        title.toString(), //index 0
        totalCalories,    //index 1
        totalCarbs,       //index 2
        totalProtein,     //index 3
        totalFat,         //index 4
        totalSugar,       //index 5
        totalSodium,      //index 6
        totalFiber        //index 7
    ];
    console.log(title.toString());
    console.log(scoreMeal(totals));
}

function inputCombo() {
    let comboArr = [];

    function recursiveInput() {
        rl.question("Input Food Item You Would Like to Add to Meal: (Enter 'stop' if you're done)", (prompt) => {
            prompt = prompt.trim();

            if (prompt === "stop") {
                console.log("Food combo: ", comboArr);
                rl.close();
                foodCombo(comboArr); // Call foodCombo only after input is complete
            } else {
                checkIfExists(prompt).then(d => {
                    if (d) {
                        comboArr.push(prompt);
                    } else {
                        console.log("Input does not exist. Please input a valid item.");
                    }
                    recursiveInput(); // Call recursively to prompt for next input
                });
            }
        });
    }

    recursiveInput();
}


module.exports = inputCombo;

