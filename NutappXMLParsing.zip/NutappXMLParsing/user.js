'use strict';

module.exports = class User{
    constructor(){
        this.kcal = 2000
        this.carb = 225
        this.protein = 175
        this.fat = 57
        this.sugar = 50
        this.sodium = 50
        this.dietrayfiber = 50
        this.eaten = []

    }

    get getKcal(){
        return this.kcal;
    }
    get getCarb(){
        return this.carb;
    }
    get getProtein(){
        return this.protein;
    }
    get getFat(){
        return this.fat;
    }
    get getSodium(){
        return this.sodium;
    }
    get getFiber(){
        return this.dietrayfiber;
    }
}